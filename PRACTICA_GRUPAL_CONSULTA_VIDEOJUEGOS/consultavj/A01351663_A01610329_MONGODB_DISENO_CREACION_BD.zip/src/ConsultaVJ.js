import React from 'react';
import { MainAppRouter } from './routers/MainAppRouter';
export const ConsultaVJ = () => {
    return (
        <MainAppRouter />
    )
}